// Abrir carrinho
let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let list = document.querySelector('.list');
let listCard = document.querySelector('.listCard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

// Abrir carrinho
openShopping.addEventListener('click', () => {
    body.classList.add('active');
});

// Fechar carrinho
closeShopping.addEventListener('click', () => {
    body.classList.remove('active');
});

// Definindo os produtos
let products = [
    {
        id: 1,
        name: 'TRADICIONAL LIMA',
        image: 'f1.png',
        price: 2000, // Preço em centavos
    },
    {
        id: 2,
        name: 'LIMA CHIKEN',
        image: 'f3.png',
        price: 1500, // Preço em centavos
    }
    ,
    {
        id: 3,
        name: 'LIMA FISH',
        image: 'f6.png',
        price: 1300, // Preço em centavos
    }
];

let listCards = [];

// Inicializa os produtos na página
function initApp() {
    products.forEach((value, key) => {
        let newDiv = document.createElement('div');
        newDiv.classList.add('item');
        newDiv.innerHTML = `
            <img src="images/${value.image}" alt="${value.name}"/>
            <div class="title">${value.name}</div>
            <div class="price">R$${(value.price / 100).toFixed(2)}</div>
            <button class="add-to-cart-btn" data-index="${key}">Adicionar ao carrinho</button>`;
        list.appendChild(newDiv);
    });
}
initApp();

// Função para adicionar o produto ao carrinho
function addToCard(key) {
    let product = products[key];
    
    // Verifica se o produto já está no carrinho
    let found = listCards.find(item => item.id === product.id);
    if (found) {
        found.quantity++; // Se o produto já estiver no carrinho, incrementa a quantidade
    } else {
        listCards.push({ ...product, quantity: 1 }); // Caso contrário, adiciona ao carrinho com quantidade 1
    }
    
    reloadCard(); // Atualiza a interface do carrinho
    localStorage.setItem('carrinho', JSON.stringify(listCards)); // Armazena o carrinho no localStorage
}

// Função para recarregar a lista do carrinho
function reloadCard() {
    listCard.innerHTML = ''; // Limpa a lista do carrinho antes de recarregar
    let count = 0;
    let totalPrice = 0;
    
    listCards.forEach((value, key) => {
        totalPrice += value.price * value.quantity; // Calcula o preço total
        count += value.quantity; // Soma a quantidade total de produtos no carrinho
        
        let newDiv = document.createElement('li');
        newDiv.innerHTML = `
            <div><img src="images/${value.image}" alt="${value.name}" style="width: 50px; height: 50px; object-fit: cover;"/></div>
            <div>${value.name}</div>
            <div>$${((value.price * value.quantity) / 100).toFixed(2)}</div>
            <div>
                <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                <div class="count">${value.quantity}</div>
                <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
            </div>`;
        listCard.appendChild(newDiv);
    });
    
    total.innerText = `$${(totalPrice / 100).toFixed(2)}`; // Exibe o preço total
    quantity.innerText = count; // Exibe a quantidade total de itens
}

// Função para alterar a quantidade de um item no carrinho
function changeQuantity(key, quantity) {
    if (quantity == 0) {
        listCards.splice(key, 1); // Remove o item se a quantidade for 0
    } else {
        listCards[key].quantity = quantity; // Atualiza a quantidade
        listCards[key].price = products[key].price * quantity; // Atualiza o preço
    }
    reloadCard(); // Recarrega o carrinho
    localStorage.setItem('carrinho', JSON.stringify(listCards)); 
}

// Função para carregar o carrinho do localStorage
function loadCartFromStorage() {
    let savedCart = localStorage.getItem('carrinho');
    if (savedCart) {
        listCards = JSON.parse(savedCart); // Carrega os dados do carrinho
        reloadCard(); // Recarrega o carrinho
    }
}

// Chama a função de carregar o carrinho do localStorage
loadCartFromStorage();


document.querySelectorAll('.add-to-cart-btn').forEach(button => {
    button.addEventListener('click', (event) => {
        const index = event.target.getAttribute('data-index');
        addToCard(index);
    });
});
